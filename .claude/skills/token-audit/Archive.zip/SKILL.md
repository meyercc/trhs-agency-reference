---
name: token-audit
description: >
  Audit CSS files for design token compliance in the Treehouse project. Use this skill
  whenever you need to: check if CSS uses hardcoded values instead of design tokens,
  find tokens that are defined but never used, verify design-system.html stays in sync
  with tokens.css, or review code for token consistency before merging. Trigger on
  phrases like "audit tokens", "check for hardcoded values", "token compliance",
  "are we using tokens consistently", "clean up CSS", or any task where you're reviewing
  or writing CSS and want to make sure it follows the design system. Also trigger
  proactively after writing or modifying CSS — run the audit as a verification step.
---

# Token Compliance Audit

This skill checks the Treehouse codebase for three categories of design token issues:

1. **Hardcoded values** — CSS properties using raw hex colors, px values, font families,
   shadows, etc. that should reference tokens from `shared/tokens.css` via `var()`
2. **Unused tokens** — tokens defined in `tokens.css` but never referenced by any CSS,
   HTML, or JS file (candidates for cleanup)
3. **Doc drift** — tokens whose values in `tokens.css` don't match what's documented
   in `design-system.html` (handled by the existing `npm run audit:tokens` script)

## When to run this

- After writing or modifying any CSS in the project
- Before declaring a component "done" (use as a verification step)
- When the user asks about token consistency or CSS cleanup
- Periodically as a health check on the design system

## How to run

### Full compliance scan (hardcoded values + unused tokens)

```bash
cd "<project-root>"
node .claude/skills/token-audit/scripts/audit-compliance.mjs
```

Useful flags:
- `--fix-hints` — shows which token each hardcoded value should use (adds `→ var(--token-name)` suggestions)
- `--json` — outputs structured JSON for programmatic processing
- `--file <path>` — scan a single CSS file instead of the whole project

### Doc drift check (tokens.css ↔ design-system.html)

```bash
npm run audit:tokens
```

This is the existing audit script. Run it alongside the compliance scan for a complete picture.

### Recommended workflow

Run both together:

```bash
node .claude/skills/token-audit/scripts/audit-compliance.mjs --fix-hints && npm run audit:tokens
```

## Interpreting results

### Hardcoded values

The script reports each violation with file, line number, category, and the raw value found.
With `--fix-hints`, it also suggests the closest matching token.

**Categories:**
- `color` — hex colors like `#0d0f13` that match a token value
- `color-rgba` — raw `rgba()` calls that could use a token
- `spacing` — px values in margin, padding, gap, etc.
- `border-radius` — hardcoded radius values
- `font-size` — hardcoded font sizes
- `font-family` — font family strings not using `var(--font-*)`
- `shadow` — box-shadow with hardcoded values
- `transition-duration` — hardcoded timing values

**Not all violations are bugs.** Use judgment:

- **tokens.css itself** is excluded automatically (that's where tokens are defined)
- **Custom property definitions** (`--my-prop: 16px`) are excluded — those _are_ token declarations
- **1px and 2px values** are allowlisted — too granular for tokens
- **Inline styles in HTML** may be intentional one-offs (but prefer classes)
- **Prototype-only CSS** (`css/prototype.css`) may have layout-specific values that
  genuinely don't belong in the token system — but spacing and colors still should use tokens

When in doubt, the rule of thumb: if the value exists in `tokens.css`, use the token.
If you find yourself needing a value that _should_ be a token but isn't, propose adding
it to `tokens.css` rather than hardcoding it.

### Unused tokens

Tokens that exist in `tokens.css` but aren't referenced anywhere via `var()`, JS
`getComputedStyle`, or `setProperty`. These are candidates for removal — but check
whether they're used by the Tauri desktop shell before deleting them. Tauri system tokens (`--tauri-*`) are excluded from this check.

## Fixing violations

For each hardcoded value the script finds:

1. **Check if a matching token exists** — the `--fix-hints` flag does this automatically
2. **Replace the raw value with `var(--token-name)`** — e.g., `padding: 16px` → `padding: var(--gutter)`
3. **If no token matches**, consider whether the value should become a new token. Common
   signs: the same value appears 3+ times, or it represents a semantic concept (a specific
   gap size, a named color, a standard radius)
4. **After fixing**, re-run the audit to confirm the violation is resolved

### Quick reference: common substitutions

| Raw value | Token |
|-----------|-------|
| `#0d0f13` | `var(--bg-base)` |
| `#11141a` | `var(--bg-mid)` |
| `#161921` | `var(--bg-elevated)` |
| `#e4e8f0` | `var(--text-primary)` |
| `#00c8d7` | `var(--cyan)` or `var(--accent-color)` |
| `#ff6b2b` | `var(--orange)` |
| `#22c55e` | `var(--green)` |
| `#ef4444` | `var(--red)` |
| `16px` (spacing) | `var(--gutter)` |
| `8px` (spacing) | `var(--gutter-sm)` |
| `4px` (spacing) | `var(--gutter-xs)` |
| `16px` (radius) | `var(--radius-card)` |
| `8px` (radius) | `var(--radius)` |
| `4px` (radius) | `var(--radius-sm)` |
| `13px` (font-size) | `var(--text-body)` |
| `11px` (font-size) | `var(--text-caption)` |
| `10px` (font-size) | `var(--text-micro)` |

### Keeping it clean going forward

The goal isn't zero violations — some edge cases are fine. The goal is that every
_semantic_ value (a color that means something, a spacing rhythm, a type size from
the scale) goes through the token system. This is what makes AI-generated layouts
reliable: the tokens are the contract between the design system and any code that
consumes it. Hardcoded values break that contract.
